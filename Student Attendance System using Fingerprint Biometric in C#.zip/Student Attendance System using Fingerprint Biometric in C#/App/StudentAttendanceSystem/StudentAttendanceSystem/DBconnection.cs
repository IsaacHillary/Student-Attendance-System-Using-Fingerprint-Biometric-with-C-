﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace StudentAttendanceSystem
{
    class DBconnection
    {
        public SqlConnection con;
        public SqlCommand cmd;
        public SqlDataAdapter sda;

        public void connection()
        {       
            con = new SqlConnection(@"server=.\SQLEXPRESS; database=StudentAttendanceSystemDB; Integrated Security = true");
            con.Open();
        }

        public void dataSend(string SQL)
        {
            connection();
            cmd = new SqlCommand(SQL, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void dataGet(string SQL)
        {
            connection();
            sda = new SqlDataAdapter(SQL, con);
        }
    }
}
