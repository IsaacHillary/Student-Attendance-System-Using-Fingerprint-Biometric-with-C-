﻿namespace StudentAttendanceSystem.Forms
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AdminControlPnl = new System.Windows.Forms.Panel();
            this.sidePnl = new System.Windows.Forms.Panel();
            this.ChangeLoginBtn = new System.Windows.Forms.Button();
            this.ReportBtn = new System.Windows.Forms.Button();
            this.Std_EnrolBtn = new System.Windows.Forms.Button();
            this.CourseRegBtn = new System.Windows.Forms.Button();
            this.DashboardBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.basePnl = new System.Windows.Forms.Panel();
            this.date = new System.Windows.Forms.Label();
            this.time = new System.Windows.Forms.Label();
            this.topPnl = new System.Windows.Forms.Panel();
            this.MinimizeBtn = new System.Windows.Forms.Button();
            this.LogOutBtn = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ChildFormPnl = new System.Windows.Forms.Panel();
            this.AttendanceBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.AdminControlPnl.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.basePnl.SuspendLayout();
            this.topPnl.SuspendLayout();
            this.ChildFormPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // AdminControlPnl
            // 
            this.AdminControlPnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.AdminControlPnl.Controls.Add(this.sidePnl);
            this.AdminControlPnl.Controls.Add(this.ChangeLoginBtn);
            this.AdminControlPnl.Controls.Add(this.ReportBtn);
            this.AdminControlPnl.Controls.Add(this.Std_EnrolBtn);
            this.AdminControlPnl.Controls.Add(this.CourseRegBtn);
            this.AdminControlPnl.Controls.Add(this.DashboardBtn);
            this.AdminControlPnl.Controls.Add(this.panel2);
            this.AdminControlPnl.Cursor = System.Windows.Forms.Cursors.Default;
            this.AdminControlPnl.Dock = System.Windows.Forms.DockStyle.Left;
            this.AdminControlPnl.Location = new System.Drawing.Point(0, 0);
            this.AdminControlPnl.Name = "AdminControlPnl";
            this.AdminControlPnl.Size = new System.Drawing.Size(229, 682);
            this.AdminControlPnl.TabIndex = 0;
            // 
            // sidePnl
            // 
            this.sidePnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.sidePnl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.sidePnl.Location = new System.Drawing.Point(-5, 180);
            this.sidePnl.Name = "sidePnl";
            this.sidePnl.Size = new System.Drawing.Size(10, 50);
            this.sidePnl.TabIndex = 3;
            // 
            // ChangeLoginBtn
            // 
            this.ChangeLoginBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ChangeLoginBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ChangeLoginBtn.FlatAppearance.BorderSize = 0;
            this.ChangeLoginBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.ChangeLoginBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.ChangeLoginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeLoginBtn.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeLoginBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            this.ChangeLoginBtn.Location = new System.Drawing.Point(0, 380);
            this.ChangeLoginBtn.Name = "ChangeLoginBtn";
            this.ChangeLoginBtn.Size = new System.Drawing.Size(229, 50);
            this.ChangeLoginBtn.TabIndex = 10;
            this.ChangeLoginBtn.Text = "      Change Login";
            this.ChangeLoginBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ChangeLoginBtn.UseVisualStyleBackColor = true;
            this.ChangeLoginBtn.Click += new System.EventHandler(this.ChangeLoginBtn_Click);
            // 
            // ReportBtn
            // 
            this.ReportBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ReportBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ReportBtn.FlatAppearance.BorderSize = 0;
            this.ReportBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.ReportBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.ReportBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReportBtn.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            this.ReportBtn.Location = new System.Drawing.Point(0, 330);
            this.ReportBtn.Name = "ReportBtn";
            this.ReportBtn.Size = new System.Drawing.Size(229, 50);
            this.ReportBtn.TabIndex = 9;
            this.ReportBtn.Text = "      Attendance Report";
            this.ReportBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ReportBtn.UseVisualStyleBackColor = true;
            this.ReportBtn.Click += new System.EventHandler(this.ReportBtn_Click);
            // 
            // Std_EnrolBtn
            // 
            this.Std_EnrolBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Std_EnrolBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.Std_EnrolBtn.FlatAppearance.BorderSize = 0;
            this.Std_EnrolBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.Std_EnrolBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.Std_EnrolBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Std_EnrolBtn.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Std_EnrolBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            this.Std_EnrolBtn.Location = new System.Drawing.Point(0, 280);
            this.Std_EnrolBtn.Name = "Std_EnrolBtn";
            this.Std_EnrolBtn.Size = new System.Drawing.Size(229, 50);
            this.Std_EnrolBtn.TabIndex = 8;
            this.Std_EnrolBtn.Text = "      Manage Students";
            this.Std_EnrolBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Std_EnrolBtn.UseVisualStyleBackColor = true;
            this.Std_EnrolBtn.Click += new System.EventHandler(this.Std_EnrolBtn_Click);
            // 
            // CourseRegBtn
            // 
            this.CourseRegBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CourseRegBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.CourseRegBtn.FlatAppearance.BorderSize = 0;
            this.CourseRegBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.CourseRegBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.CourseRegBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CourseRegBtn.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CourseRegBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(230)))), ((int)(((byte)(255)))));
            this.CourseRegBtn.Location = new System.Drawing.Point(0, 230);
            this.CourseRegBtn.Name = "CourseRegBtn";
            this.CourseRegBtn.Size = new System.Drawing.Size(229, 50);
            this.CourseRegBtn.TabIndex = 7;
            this.CourseRegBtn.Text = "      Course Registration";
            this.CourseRegBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CourseRegBtn.UseVisualStyleBackColor = true;
            this.CourseRegBtn.Click += new System.EventHandler(this.CourseRegBtn_Click);
            // 
            // DashboardBtn
            // 
            this.DashboardBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DashboardBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.DashboardBtn.FlatAppearance.BorderSize = 0;
            this.DashboardBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.DashboardBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.DashboardBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DashboardBtn.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DashboardBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.DashboardBtn.Location = new System.Drawing.Point(0, 180);
            this.DashboardBtn.Name = "DashboardBtn";
            this.DashboardBtn.Size = new System.Drawing.Size(229, 50);
            this.DashboardBtn.TabIndex = 6;
            this.DashboardBtn.Text = "      Dashboard";
            this.DashboardBtn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DashboardBtn.UseVisualStyleBackColor = true;
            this.DashboardBtn.Click += new System.EventHandler(this.DashboardBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 180);
            this.panel2.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label2.Location = new System.Drawing.Point(19, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(190, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "ADMINISTRATION PANEL";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Euphorigenic", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label1.Location = new System.Drawing.Point(68, 106);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 10);
            this.label1.TabIndex = 4;
            this.label1.Text = "Knowledge Alleviates Poverty";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = global::StudentAttendanceSystem.Properties.Resources._1586386101592;
            this.pictureBox1.Location = new System.Drawing.Point(78, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 65);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // basePnl
            // 
            this.basePnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(240)))));
            this.basePnl.Controls.Add(this.date);
            this.basePnl.Controls.Add(this.time);
            this.basePnl.Cursor = System.Windows.Forms.Cursors.Default;
            this.basePnl.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.basePnl.Location = new System.Drawing.Point(229, 636);
            this.basePnl.Name = "basePnl";
            this.basePnl.Size = new System.Drawing.Size(992, 46);
            this.basePnl.TabIndex = 1;
            this.basePnl.Paint += new System.Windows.Forms.PaintEventHandler(this.basePnl_Paint);
            // 
            // date
            // 
            this.date.AutoSize = true;
            this.date.Cursor = System.Windows.Forms.Cursors.Default;
            this.date.Font = new System.Drawing.Font("Century Gothic", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.date.Location = new System.Drawing.Point(26, 3);
            this.date.Name = "date";
            this.date.Size = new System.Drawing.Size(49, 21);
            this.date.TabIndex = 3;
            this.date.Text = "date";
            // 
            // time
            // 
            this.time.AutoSize = true;
            this.time.Cursor = System.Windows.Forms.Cursors.Default;
            this.time.Font = new System.Drawing.Font("Century Gothic", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.time.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.time.Location = new System.Drawing.Point(847, 3);
            this.time.Name = "time";
            this.time.Size = new System.Drawing.Size(45, 21);
            this.time.TabIndex = 4;
            this.time.Text = "time";
            // 
            // topPnl
            // 
            this.topPnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(240)))));
            this.topPnl.Controls.Add(this.MinimizeBtn);
            this.topPnl.Controls.Add(this.LogOutBtn);
            this.topPnl.Cursor = System.Windows.Forms.Cursors.Default;
            this.topPnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPnl.Location = new System.Drawing.Point(229, 0);
            this.topPnl.Name = "topPnl";
            this.topPnl.Size = new System.Drawing.Size(992, 34);
            this.topPnl.TabIndex = 2;
            // 
            // MinimizeBtn
            // 
            this.MinimizeBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.MinimizeBtn.FlatAppearance.BorderSize = 0;
            this.MinimizeBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(33)))), ((int)(((byte)(98)))));
            this.MinimizeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinimizeBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(8)))), ((int)(((byte)(61)))));
            this.MinimizeBtn.Image = global::StudentAttendanceSystem.Properties.Resources.Minus;
            this.MinimizeBtn.Location = new System.Drawing.Point(890, 0);
            this.MinimizeBtn.Name = "MinimizeBtn";
            this.MinimizeBtn.Size = new System.Drawing.Size(51, 34);
            this.MinimizeBtn.TabIndex = 3;
            this.MinimizeBtn.UseVisualStyleBackColor = true;
            this.MinimizeBtn.Click += new System.EventHandler(this.MinimizeBtn_Click);
            // 
            // LogOutBtn
            // 
            this.LogOutBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogOutBtn.FlatAppearance.BorderSize = 0;
            this.LogOutBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(33)))), ((int)(((byte)(98)))));
            this.LogOutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.LogOutBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(6)))), ((int)(((byte)(8)))), ((int)(((byte)(61)))));
            this.LogOutBtn.Image = global::StudentAttendanceSystem.Properties.Resources.Exit;
            this.LogOutBtn.Location = new System.Drawing.Point(941, 0);
            this.LogOutBtn.Name = "LogOutBtn";
            this.LogOutBtn.Size = new System.Drawing.Size(51, 34);
            this.LogOutBtn.TabIndex = 3;
            this.LogOutBtn.UseVisualStyleBackColor = true;
            this.LogOutBtn.Click += new System.EventHandler(this.LogOutBtn_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ChildFormPnl
            // 
            this.ChildFormPnl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(240)))));
            this.ChildFormPnl.Controls.Add(this.AttendanceBtn);
            this.ChildFormPnl.Controls.Add(this.label3);
            this.ChildFormPnl.Controls.Add(this.pictureBox2);
            this.ChildFormPnl.Cursor = System.Windows.Forms.Cursors.Default;
            this.ChildFormPnl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ChildFormPnl.Location = new System.Drawing.Point(229, 34);
            this.ChildFormPnl.Name = "ChildFormPnl";
            this.ChildFormPnl.Size = new System.Drawing.Size(992, 602);
            this.ChildFormPnl.TabIndex = 3;
            // 
            // AttendanceBtn
            // 
            this.AttendanceBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.AttendanceBtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AttendanceBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.AttendanceBtn.FlatAppearance.BorderSize = 0;
            this.AttendanceBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(57)))), ((int)(((byte)(101)))));
            this.AttendanceBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AttendanceBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AttendanceBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(150)))), ((int)(((byte)(2)))));
            this.AttendanceBtn.Location = new System.Drawing.Point(419, 531);
            this.AttendanceBtn.Name = "AttendanceBtn";
            this.AttendanceBtn.Size = new System.Drawing.Size(184, 52);
            this.AttendanceBtn.TabIndex = 2;
            this.AttendanceBtn.Text = "Take Attendance";
            this.AttendanceBtn.UseVisualStyleBackColor = false;
            this.AttendanceBtn.Click += new System.EventHandler(this.AttendanceBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("News706 BT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label3.Location = new System.Drawing.Point(289, 483);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(443, 29);
            this.label3.TabIndex = 1;
            this.label3.Text = "STUDENT ATTENDANCE SYSTEM";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox2.Image = global::StudentAttendanceSystem.Properties.Resources._1587236365949;
            this.pictureBox2.Location = new System.Drawing.Point(286, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(448, 466);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(194)))), ((int)(((byte)(194)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1221, 682);
            this.Controls.Add(this.ChildFormPnl);
            this.Controls.Add(this.topPnl);
            this.Controls.Add(this.basePnl);
            this.Controls.Add(this.AdminControlPnl);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdminForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminForm";
            this.AdminControlPnl.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.basePnl.ResumeLayout(false);
            this.basePnl.PerformLayout();
            this.topPnl.ResumeLayout(false);
            this.ChildFormPnl.ResumeLayout(false);
            this.ChildFormPnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel AdminControlPnl;
        private System.Windows.Forms.Panel basePnl;
        private System.Windows.Forms.Panel topPnl;
        private System.Windows.Forms.Button LogOutBtn;
        private System.Windows.Forms.Button MinimizeBtn;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button DashboardBtn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel sidePnl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ReportBtn;
        private System.Windows.Forms.Button Std_EnrolBtn;
        private System.Windows.Forms.Button CourseRegBtn;
        private System.Windows.Forms.Button ChangeLoginBtn;
        private System.Windows.Forms.Label date;
        private System.Windows.Forms.Label time;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel ChildFormPnl;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AttendanceBtn;
    }
}