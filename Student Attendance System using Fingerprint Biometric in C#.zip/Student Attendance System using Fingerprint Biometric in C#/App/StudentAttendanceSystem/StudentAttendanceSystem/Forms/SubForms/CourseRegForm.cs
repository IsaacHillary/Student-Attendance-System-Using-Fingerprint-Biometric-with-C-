﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class CourseRegForm : Form
    {
        public CourseRegForm()
        {
            InitializeComponent();
            session();
        }

        private void ClearAll()
        {
            txtLecturer.Clear();
            txtCourseTitle.Clear();
            txtCourseCode.Clear();
            cbLevel.SelectedIndex = -1;
            cbSession.SelectedIndex = 0;
            cbSemester.SelectedIndex = -1;
            cbUnit.SelectedIndex = -1;
            cbFaculty.SelectedIndex = -1;
            cbDepartment.SelectedIndex = -1;
        }

        DBconnection con = new DBconnection();
        public class cbItem
        {
            public string Name;
            public List<cbItem> SubItems = new List<cbItem>();

            public cbItem(string name)
            {
                this.Name = name;
            }

            public override string ToString()
            {
                return Name;
            }
        }

        // Session Combobox from database
        private void session()
        {
            DataRow dr;
            SqlConnection conn = new SqlConnection(@"server=.\SQLEXPRESS; database=StudentAttendanceSystemDB; Integrated Security = true");
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from SessionTb", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dr = dt.NewRow();
            dr.ItemArray = new object[] {0, ""};
            dt.Rows.InsertAt(dr, 0);
            cbSession.ValueMember = "SessionID";
            cbSession.DisplayMember = "Session";
            cbSession.DataSource = dt;
            conn.Close();
        }

        private void CourseRegForm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtLecturer;
            btnSave.Visible = true;
            btnDelete.Enabled = false;
            btnUpdate.Visible = false;
            btnClearAll.Visible = true;
            btnCancel.Visible = false;
            LoadData();
            //create a list for data items (Faculty)
            List<cbItem> cbFacultyItem = new List<cbItem>();

            //assign sub items (Department)
            cbFacultyItem.Add(new cbItem("Humanities and Arts")
            {
                SubItems = { new cbItem("Mass Communication") }
            });

            cbFacultyItem.Add(new cbItem("Law")
            {
                SubItems = { new cbItem("Law") }
            });

            cbFacultyItem.Add(new cbItem("Management and Social Sciences")
            {
                SubItems = { new cbItem("Accounting"), new cbItem("Banking and Finance"),
                    new cbItem("Business Administration"), new cbItem("Economics") }
            });

            cbFacultyItem.Add(new cbItem("Natural and Applied Sciences")
            {
                SubItems = { new cbItem("Biochemistry"), new cbItem("Biology"), 
                    new cbItem("Biotechnology"), new cbItem("Computer Science"),
                    new cbItem("Industrial Chemistry"), new cbItem("Industrial Mathematics"),
                    new cbItem("Industrial Physics") }
            });
            cbFacultyItem.Add(new cbItem("General")
            {
                SubItems = { new cbItem("General") }
            });

            //load data items into cbFaculty
            cbFaculty.Items.AddRange(cbFacultyItem.ToArray());
        }

        private void cbFaculty_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get the combobox item
            cbItem item = (sender as ComboBox).SelectedItem as cbItem;

            //make sure no shinanigans are going on
            if (item == null)
                return;

            //clear out cbDepartment
            cbDepartment.Items.Clear();

            //add sub items to cbDepartment
            cbDepartment.Items.AddRange(item.SubItems.ToArray());
        }

        private bool CourseCodeExist()
        {
            con.dataGet("Select 2 from CourseTb where (CourseCode= '" + txtCourseCode.Text + "' and Session= '"+ cbSession.Text + "')");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        // Validation to make sure Course Registeration fields are not empty
        private bool validation()
        {
            bool result = false;
            if (string.IsNullOrEmpty(txtLecturer.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(panel1, "Lecturer Name Required");
            }
            else if (string.IsNullOrEmpty(cbFaculty.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbFaculty, "Faculty Required");
            }
            else if (string.IsNullOrEmpty(cbDepartment.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbDepartment, "Department Required");
            }
            else if (string.IsNullOrEmpty(txtCourseTitle.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(panel2, "Course Title Required");
            }
            else if (string.IsNullOrEmpty(txtCourseCode.Text))
            {
                errorProvider.Clear(); 
                errorProvider.SetError(panel3, "Course Code Required");
            }
            else if (string.IsNullOrEmpty(cbLevel.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbLevel, "Course Level Required");
            }
            else if (string.IsNullOrEmpty(cbSession.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbSession, "Session Required");
            }
            else if (string.IsNullOrEmpty(cbSemester.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbSemester, "Semester Required");
            }
            else if (string.IsNullOrEmpty(cbUnit.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbUnit, "Course Unit Required");
            }
            else
            {
                errorProvider.Clear();
                result = true;
            }
            return result;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(validation())
            {
                if (CourseCodeExist())
                {
                    MessageBox.Show("This course has already been registered in this academic session","Existing Course",MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
                }
                else
                {
                    con.dataSend("INSERT INTO CourseTb (LecturerName, CourseTitle, CourseCode, Faculty, Department, Session, Semester, CourseLevel, CourseUnit, RegDate) VALUES('"+txtLecturer.Text+"','"+txtCourseTitle.Text+"','"+txtCourseCode.Text+"','"+cbFaculty.Text+"','"+cbDepartment.Text+"','"+cbSession.Text+"','"+cbSemester.Text+"','"+cbLevel.Text+"','"+cbUnit.Text+"',GetDate())");
                    MessageBox.Show("Course Saved Successfully");
                    ClearAll();
                    LoadData();
                }
            }
        }

        private void LoadData()
        {
            con.dataGet("SELECT LecturerName, CourseTitle, CourseCode, Faculty, Department, Session, Semester, CourseLevel, CourseUnit, RegDate, CourseID FROM CourseTb");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridVeiw.Rows.Clear();
            foreach (DataRow row in dt.Rows)
            {
                int n = dataGridVeiw.Rows.Add();
                dataGridVeiw.Rows[n].Cells["sn"].Value = n + 1;
                dataGridVeiw.Rows[n].Cells["ln"].Value = row["LecturerName"].ToString();
                dataGridVeiw.Rows[n].Cells["ct"].Value = row["CourseTitle"].ToString();
                dataGridVeiw.Rows[n].Cells["cc"].Value = row["CourseCode"].ToString();
                dataGridVeiw.Rows[n].Cells["cf"].Value = row["Faculty"].ToString();
                dataGridVeiw.Rows[n].Cells["cd"].Value = row["Department"].ToString();
                dataGridVeiw.Rows[n].Cells["ses"].Value = row["Session"].ToString();
                dataGridVeiw.Rows[n].Cells["sem"].Value = row["Semester"].ToString();
                dataGridVeiw.Rows[n].Cells["cl"].Value = row["CourseLevel"].ToString();
                dataGridVeiw.Rows[n].Cells["cu"].Value = row["CourseUnit"].ToString();
                dataGridVeiw.Rows[n].Cells["reg"].Value = Convert.ToDateTime(row["RegDate"].ToString()).ToString("dd/MM/yyyy");
                dataGridVeiw.Rows[n].Cells["Data_id"].Value = row["CourseID"].ToString();
            }
        }

        private void dataGridVeiw_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtLecturer.Text = dataGridVeiw.SelectedRows[0].Cells["ln"].Value.ToString();
            txtCourseTitle.Text = dataGridVeiw.SelectedRows[0].Cells["ct"].Value.ToString();
            txtCourseCode.Text = dataGridVeiw.SelectedRows[0].Cells["cc"].Value.ToString();
            cbFaculty.Text = dataGridVeiw.SelectedRows[0].Cells["cf"].Value.ToString();
            cbDepartment.Text = dataGridVeiw.SelectedRows[0].Cells["cd"].Value.ToString();
            cbSession.Text = dataGridVeiw.SelectedRows[0].Cells["ses"].Value.ToString();
            cbSemester.Text = dataGridVeiw.SelectedRows[0].Cells["sem"].Value.ToString();
            cbLevel.Text = dataGridVeiw.SelectedRows[0].Cells["cl"].Value.ToString();
            cbUnit.Text = dataGridVeiw.SelectedRows[0].Cells["cu"].Value.ToString();
            labelID.Text = dataGridVeiw.SelectedRows[0].Cells["Data_id"].Value.ToString();

            btnSave.Visible = false;
            btnUpdate.Visible = true;
            btnDelete.Enabled = true;
            btnClearAll.Visible = false;
            btnCancel.Visible = true;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Do you want to update the information?", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dialog == DialogResult.Yes)
            {
                if (validation())
                {
                    if (CourseCodeExist())
                    {
                        MessageBox.Show("This course has already been registered in this academic session", "Existing Course", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                        con.dataSend("UPDATE CourseTb SET LecturerName ='" + txtLecturer.Text + "', CourseTitle ='" + txtCourseTitle.Text + "', CourseCode ='" + txtCourseCode.Text + "', Faculty ='" + cbFaculty.Text + "', Department ='" + cbDepartment.Text + "', Session ='" + cbSession.Text + "', Semester ='" + cbSemester.Text + "', CourseLevel ='" + cbLevel.Text + "', CourseUnit ='" + cbUnit.Text + "', RegDate = GetDate() where CourseID ='" + labelID.Text + "' ");
                        MessageBox.Show("Updated Successfully", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearAll();
                        LoadData();
                        btnSave.Visible = true;
                        btnUpdate.Visible = false;
                        btnDelete.Enabled = false;
                        btnClearAll.Enabled = true;
                    }                
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            labelID.Text = null;
            ClearAll();
            LoadData();
            this.ActiveControl = txtLecturer;
            btnSave.Visible = true;
            btnDelete.Enabled = false;
            btnUpdate.Visible = false;
            btnClearAll.Visible = true;
            btnCancel.Visible = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Do you want to delete the record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                con.dataSend("Delete from CourseTb where CourseID='" + labelID.Text + "'");
                MessageBox.Show("Record Deleted Successfully", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearAll();
                LoadData();
                this.ActiveControl = txtLecturer;
                btnSave.Visible = true;
                btnDelete.Enabled = false;
                btnUpdate.Visible = false;
                btnClearAll.Visible = true;
                btnCancel.Visible = false;
            }
        }
    }
}
