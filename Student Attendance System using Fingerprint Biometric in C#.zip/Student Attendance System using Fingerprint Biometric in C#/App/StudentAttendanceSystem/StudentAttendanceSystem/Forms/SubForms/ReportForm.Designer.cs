﻿namespace StudentAttendanceSystem.Forms.SubForms
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridVeiw = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.cbSelectCourse = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AttBtn = new System.Windows.Forms.Button();
            this.PercentBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.sn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.on = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.f = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.d = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.l = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.coursetitle = new System.Windows.Forms.Label();
            this.semester = new System.Windows.Forms.Label();
            this.session = new System.Windows.Forms.Label();
            this.numericUpDown = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridVeiw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("News706 BT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label3.Location = new System.Drawing.Point(293, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(445, 29);
            this.label3.TabIndex = 17;
            this.label3.Text = "STUDENT ATTENDANCE REPORT";
            // 
            // dataGridVeiw
            // 
            this.dataGridVeiw.AllowUserToAddRows = false;
            this.dataGridVeiw.AllowUserToResizeColumns = false;
            this.dataGridVeiw.AllowUserToResizeRows = false;
            this.dataGridVeiw.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridVeiw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridVeiw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridVeiw.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sn,
            this.surn,
            this.on,
            this.mn,
            this.f,
            this.d,
            this.l,
            this.c,
            this.AC,
            this.AP});
            this.dataGridVeiw.Location = new System.Drawing.Point(10, 128);
            this.dataGridVeiw.Name = "dataGridVeiw";
            this.dataGridVeiw.RowHeadersVisible = false;
            this.dataGridVeiw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridVeiw.Size = new System.Drawing.Size(972, 467);
            this.dataGridVeiw.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label1.Location = new System.Drawing.Point(241, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 18);
            this.label1.TabIndex = 17;
            this.label1.Text = "Select the course code";
            // 
            // cbSelectCourse
            // 
            this.cbSelectCourse.BackColor = System.Drawing.SystemColors.Window;
            this.cbSelectCourse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSelectCourse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbSelectCourse.Font = new System.Drawing.Font("Tahoma", 8F);
            this.cbSelectCourse.Location = new System.Drawing.Point(245, 66);
            this.cbSelectCourse.Name = "cbSelectCourse";
            this.cbSelectCourse.Size = new System.Drawing.Size(149, 21);
            this.cbSelectCourse.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Default;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 13F);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label2.Location = new System.Drawing.Point(14, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 22);
            this.label2.TabIndex = 17;
            this.label2.Text = "Course Title :";
            // 
            // AttBtn
            // 
            this.AttBtn.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.AttBtn.FlatAppearance.BorderSize = 0;
            this.AttBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AttBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.AttBtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.AttBtn.Location = new System.Drawing.Point(407, 61);
            this.AttBtn.Name = "AttBtn";
            this.AttBtn.Size = new System.Drawing.Size(97, 27);
            this.AttBtn.TabIndex = 30;
            this.AttBtn.Text = "View Attendance";
            this.AttBtn.UseVisualStyleBackColor = false;
            this.AttBtn.Click += new System.EventHandler(this.AttBtn_Click);
            // 
            // PercentBtn
            // 
            this.PercentBtn.BackColor = System.Drawing.Color.DarkGreen;
            this.PercentBtn.FlatAppearance.BorderSize = 0;
            this.PercentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PercentBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.PercentBtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PercentBtn.Location = new System.Drawing.Point(633, 62);
            this.PercentBtn.Name = "PercentBtn";
            this.PercentBtn.Size = new System.Drawing.Size(97, 27);
            this.PercentBtn.TabIndex = 30;
            this.PercentBtn.Text = "View Percentage";
            this.PercentBtn.UseVisualStyleBackColor = false;
            this.PercentBtn.Visible = false;
            this.PercentBtn.Click += new System.EventHandler(this.PercentBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Cursor = System.Windows.Forms.Cursors.Default;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label4.Location = new System.Drawing.Point(573, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 18);
            this.label4.TabIndex = 17;
            this.label4.Text = "No. of classes held";
            this.label4.Visible = false;
            // 
            // sn
            // 
            this.sn.HeaderText = "S/N";
            this.sn.Name = "sn";
            this.sn.ReadOnly = true;
            this.sn.Width = 35;
            // 
            // surn
            // 
            this.surn.HeaderText = "SURNAME";
            this.surn.Name = "surn";
            this.surn.ReadOnly = true;
            this.surn.Width = 105;
            // 
            // on
            // 
            this.on.HeaderText = "OTHER NAMES";
            this.on.Name = "on";
            this.on.ReadOnly = true;
            this.on.Width = 160;
            // 
            // mn
            // 
            this.mn.HeaderText = "MATRIC NO.";
            this.mn.Name = "mn";
            this.mn.ReadOnly = true;
            this.mn.Width = 120;
            // 
            // f
            // 
            this.f.HeaderText = "FACULTY";
            this.f.Name = "f";
            this.f.ReadOnly = true;
            this.f.Width = 160;
            // 
            // d
            // 
            this.d.HeaderText = "DEPARTMENT";
            this.d.Name = "d";
            this.d.ReadOnly = true;
            this.d.Width = 140;
            // 
            // l
            // 
            this.l.HeaderText = "LEVEL";
            this.l.Name = "l";
            this.l.ReadOnly = true;
            this.l.Width = 50;
            // 
            // c
            // 
            this.c.HeaderText = "COURSE";
            this.c.Name = "c";
            this.c.Width = 60;
            // 
            // AC
            // 
            this.AC.HeaderText = "ATT. COUNT";
            this.AC.Name = "AC";
            this.AC.Width = 53;
            // 
            // AP
            // 
            this.AP.HeaderText = "ATT. COUNT (%)";
            this.AP.Name = "AP";
            this.AP.Width = 85;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Default;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 13F);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label5.Location = new System.Drawing.Point(496, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 22);
            this.label5.TabIndex = 17;
            this.label5.Text = "Semester :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Cursor = System.Windows.Forms.Cursors.Default;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 13F);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label6.Location = new System.Drawing.Point(810, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 22);
            this.label6.TabIndex = 17;
            this.label6.Text = "Session :";
            // 
            // coursetitle
            // 
            this.coursetitle.AutoSize = true;
            this.coursetitle.Cursor = System.Windows.Forms.Cursors.Default;
            this.coursetitle.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.coursetitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.coursetitle.Location = new System.Drawing.Point(134, 102);
            this.coursetitle.Name = "coursetitle";
            this.coursetitle.Size = new System.Drawing.Size(30, 20);
            this.coursetitle.TabIndex = 17;
            this.coursetitle.Text = "???";
            // 
            // semester
            // 
            this.semester.AutoSize = true;
            this.semester.Cursor = System.Windows.Forms.Cursors.Default;
            this.semester.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.semester.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.semester.Location = new System.Drawing.Point(589, 103);
            this.semester.Name = "semester";
            this.semester.Size = new System.Drawing.Size(30, 20);
            this.semester.TabIndex = 32;
            this.semester.Text = "???";
            // 
            // session
            // 
            this.session.AutoSize = true;
            this.session.Cursor = System.Windows.Forms.Cursors.Default;
            this.session.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.session.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.session.Location = new System.Drawing.Point(888, 103);
            this.session.Name = "session";
            this.session.Size = new System.Drawing.Size(30, 20);
            this.session.TabIndex = 33;
            this.session.Text = "???";
            // 
            // numericUpDown
            // 
            this.numericUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.numericUpDown.Location = new System.Drawing.Point(576, 65);
            this.numericUpDown.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown.Name = "numericUpDown";
            this.numericUpDown.Size = new System.Drawing.Size(43, 23);
            this.numericUpDown.TabIndex = 34;
            this.numericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown.Visible = false;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(992, 602);
            this.Controls.Add(this.numericUpDown);
            this.Controls.Add(this.session);
            this.Controls.Add(this.semester);
            this.Controls.Add(this.PercentBtn);
            this.Controls.Add(this.AttBtn);
            this.Controls.Add(this.cbSelectCourse);
            this.Controls.Add(this.dataGridVeiw);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.coursetitle);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ReportForm";
            this.Text = "ReportForm";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridVeiw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridVeiw;
        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.ComboBox cbSelectCourse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button AttBtn;
        private System.Windows.Forms.Button PercentBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn sn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surn;
        private System.Windows.Forms.DataGridViewTextBoxColumn on;
        private System.Windows.Forms.DataGridViewTextBoxColumn mn;
        private System.Windows.Forms.DataGridViewTextBoxColumn f;
        private System.Windows.Forms.DataGridViewTextBoxColumn d;
        private System.Windows.Forms.DataGridViewTextBoxColumn l;
        private System.Windows.Forms.DataGridViewTextBoxColumn c;
        private System.Windows.Forms.DataGridViewTextBoxColumn AC;
        private System.Windows.Forms.DataGridViewTextBoxColumn AP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label coursetitle;
        private System.Windows.Forms.Label semester;
        private System.Windows.Forms.Label session;
        private System.Windows.Forms.NumericUpDown numericUpDown;
    }
}