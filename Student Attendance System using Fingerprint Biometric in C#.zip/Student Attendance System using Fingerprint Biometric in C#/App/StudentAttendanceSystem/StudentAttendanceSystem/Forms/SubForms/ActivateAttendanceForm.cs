﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class ActivateAttendanceForm : Form
    {
        public static int x;
        public static string y;
        public ActivateAttendanceForm()
        {
            InitializeComponent();
        }

        private bool validation()
        {
            bool result = false;
            if (string.IsNullOrEmpty(cbSelectCourse.Text))
            {
                MessageBox.Show("Select a course to activate");
            }
            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Provide admin password to activate");
            }
            else
            {
                result = true;
            }
            return result;
        }

        public void btnActivate_Click(object sender, EventArgs e)
        {
            DBconnection con = new DBconnection();
            con.dataGet("SELECT * FROM LoginTb WHERE (password='" + txtPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS)");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);

            if (validation())
            {
                if (dt.Rows.Count > 0)
                {
                    x = Convert.ToInt32(numericUpDown1.Value);
                    y = cbSelectCourse.Text;
                    new AttendanceForm().ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Incorrect Password, Please try again", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtPassword.Clear();
                }
            }  
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void ActivateAttendanceForm_Load(object sender, EventArgs e)
        {
            DataRow dr;
            SqlConnection conn = new SqlConnection(@"server=.\SQLEXPRESS; database=StudentAttendanceSystemDB; Integrated Security = true");
            conn.Open();
            SqlCommand cmd = new SqlCommand("select CourseID, CourseCode from CourseTb", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dr = dt.NewRow();
            dr.ItemArray = new object[] { 0, "" };
            dt.Rows.InsertAt(dr, 0);
            cbSelectCourse.ValueMember = "CourseID";
            cbSelectCourse.DisplayMember = "CourseCode";
            cbSelectCourse.DataSource = dt;
            conn.Close();
        }
    }
}
