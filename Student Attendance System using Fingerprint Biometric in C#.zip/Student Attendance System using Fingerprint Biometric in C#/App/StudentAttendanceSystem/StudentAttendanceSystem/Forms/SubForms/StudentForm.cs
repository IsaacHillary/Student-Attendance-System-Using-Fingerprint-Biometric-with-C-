﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
        }

        DBconnection con = new DBconnection();

        private void btnAdd_Std_Click(object sender, EventArgs e)
        {
            new EnrolForm().ShowDialog();
        }

        private void btnDelete_Std_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Do you want to delete the record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
               con.dataSend("Delete from StudentTb where StudentID='" + labelID.Text + "'");
               MessageBox.Show("Record Deleted Successfully", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
               LoadData();
            }
        }

        private void LoadData()
        {
            con.dataGet("SELECT Surname, Other_names, Gender, Std_matric, Faculty, Department, Std_level, Std_course, Reg_date, StudentID FROM StudentTb");
            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridVeiw.Rows.Clear();
            foreach (DataRow row in dt.Rows)
            {
                int n = dataGridVeiw.Rows.Add();
                dataGridVeiw.Rows[n].Cells["sn"].Value = n + 1;
                dataGridVeiw.Rows[n].Cells["surn"].Value = row["Surname"].ToString();
                dataGridVeiw.Rows[n].Cells["on"].Value = row["Other_names"].ToString();
                dataGridVeiw.Rows[n].Cells["g"].Value = row["Gender"].ToString();
                dataGridVeiw.Rows[n].Cells["mn"].Value = row["Std_matric"].ToString();
                dataGridVeiw.Rows[n].Cells["f"].Value = row["Faculty"].ToString();
                dataGridVeiw.Rows[n].Cells["d"].Value = row["Department"].ToString();
                dataGridVeiw.Rows[n].Cells["l"].Value = row["Std_level"].ToString();
                dataGridVeiw.Rows[n].Cells["c"].Value = row["Std_course"].ToString();
                dataGridVeiw.Rows[n].Cells["reg"].Value = Convert.ToDateTime(row["Reg_date"].ToString()).ToString("dd/MM/yyyy");
                dataGridVeiw.Rows[n].Cells["Data_id"].Value = row["StudentID"].ToString();
            }
        }

        private void StudentForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dataGridVeiw_MouseClick(object sender, MouseEventArgs e)
        {
            labelID.Text = dataGridVeiw.SelectedRows[0].Cells["Data_id"].Value.ToString();
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
