﻿namespace StudentAttendanceSystem.Forms.SubForms
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BtnDelete_Std = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridVeiw = new System.Windows.Forms.DataGridView();
            this.sn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.on = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.g = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.f = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.d = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.l = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Data_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelID = new System.Windows.Forms.Label();
            this.RefreshList = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridVeiw)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnDelete_Std
            // 
            this.BtnDelete_Std.BackColor = System.Drawing.Color.DarkRed;
            this.BtnDelete_Std.FlatAppearance.BorderSize = 0;
            this.BtnDelete_Std.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDelete_Std.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.BtnDelete_Std.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.BtnDelete_Std.Location = new System.Drawing.Point(647, 560);
            this.BtnDelete_Std.Name = "BtnDelete_Std";
            this.BtnDelete_Std.Size = new System.Drawing.Size(86, 32);
            this.BtnDelete_Std.TabIndex = 13;
            this.BtnDelete_Std.Text = "Delete";
            this.BtnDelete_Std.UseVisualStyleBackColor = false;
            this.BtnDelete_Std.Click += new System.EventHandler(this.btnDelete_Std_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Green;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(261, 560);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 32);
            this.button1.TabIndex = 13;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnAdd_Std_Click);
            // 
            // dataGridVeiw
            // 
            this.dataGridVeiw.AllowUserToAddRows = false;
            this.dataGridVeiw.AllowUserToResizeColumns = false;
            this.dataGridVeiw.AllowUserToResizeRows = false;
            this.dataGridVeiw.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridVeiw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridVeiw.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridVeiw.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sn,
            this.surn,
            this.on,
            this.g,
            this.mn,
            this.f,
            this.d,
            this.l,
            this.c,
            this.reg,
            this.Data_id});
            this.dataGridVeiw.Location = new System.Drawing.Point(10, 52);
            this.dataGridVeiw.Name = "dataGridVeiw";
            this.dataGridVeiw.RowHeadersVisible = false;
            this.dataGridVeiw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridVeiw.Size = new System.Drawing.Size(972, 505);
            this.dataGridVeiw.TabIndex = 14;
            this.dataGridVeiw.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridVeiw_MouseClick);
            // 
            // sn
            // 
            this.sn.HeaderText = "S/N";
            this.sn.Name = "sn";
            this.sn.ReadOnly = true;
            this.sn.Width = 35;
            // 
            // surn
            // 
            this.surn.HeaderText = "SURNAME";
            this.surn.Name = "surn";
            this.surn.ReadOnly = true;
            this.surn.Width = 105;
            // 
            // on
            // 
            this.on.HeaderText = "OTHER NAMES";
            this.on.Name = "on";
            this.on.ReadOnly = true;
            this.on.Width = 170;
            // 
            // g
            // 
            this.g.HeaderText = "GENDER";
            this.g.Name = "g";
            this.g.ReadOnly = true;
            this.g.Width = 60;
            // 
            // mn
            // 
            this.mn.HeaderText = "MATRIC NO.";
            this.mn.Name = "mn";
            this.mn.ReadOnly = true;
            this.mn.Width = 120;
            // 
            // f
            // 
            this.f.HeaderText = "FACULTY";
            this.f.Name = "f";
            this.f.ReadOnly = true;
            this.f.Width = 160;
            // 
            // d
            // 
            this.d.HeaderText = "DEPARTMENT";
            this.d.Name = "d";
            this.d.ReadOnly = true;
            this.d.Width = 140;
            // 
            // l
            // 
            this.l.HeaderText = "LEVEL";
            this.l.Name = "l";
            this.l.ReadOnly = true;
            this.l.Width = 50;
            // 
            // c
            // 
            this.c.HeaderText = "COURSE";
            this.c.Name = "c";
            this.c.Width = 60;
            // 
            // reg
            // 
            this.reg.HeaderText = "REG. DATE";
            this.reg.Name = "reg";
            this.reg.ReadOnly = true;
            this.reg.Width = 67;
            // 
            // Data_id
            // 
            this.Data_id.HeaderText = "ID";
            this.Data_id.MinimumWidth = 3;
            this.Data_id.Name = "Data_id";
            this.Data_id.ReadOnly = true;
            this.Data_id.Width = 3;
            // 
            // labelID
            // 
            this.labelID.AutoSize = true;
            this.labelID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.labelID.Location = new System.Drawing.Point(460, 560);
            this.labelID.Name = "labelID";
            this.labelID.Size = new System.Drawing.Size(35, 13);
            this.labelID.TabIndex = 15;
            this.labelID.Text = "label1";
            this.labelID.Visible = false;
            // 
            // RefreshList
            // 
            this.RefreshList.BackColor = System.Drawing.Color.Gray;
            this.RefreshList.FlatAppearance.BorderSize = 0;
            this.RefreshList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RefreshList.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F);
            this.RefreshList.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.RefreshList.Location = new System.Drawing.Point(905, 558);
            this.RefreshList.Name = "RefreshList";
            this.RefreshList.Size = new System.Drawing.Size(77, 22);
            this.RefreshList.TabIndex = 13;
            this.RefreshList.Text = "Refresh List";
            this.RefreshList.UseVisualStyleBackColor = false;
            this.RefreshList.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Default;
            this.label3.Font = new System.Drawing.Font("News706 BT", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(7)))), ((int)(((byte)(51)))));
            this.label3.Location = new System.Drawing.Point(359, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(295, 29);
            this.label3.TabIndex = 16;
            this.label3.Text = "ENROLLED STUDENT";
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(240)))));
            this.ClientSize = new System.Drawing.Size(992, 602);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.labelID);
            this.Controls.Add(this.dataGridVeiw);
            this.Controls.Add(this.RefreshList);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BtnDelete_Std);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentForm";
            this.Text = "EnrolForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridVeiw)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BtnDelete_Std;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridVeiw;
        private System.Windows.Forms.Label labelID;
        private System.Windows.Forms.Button RefreshList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn sn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surn;
        private System.Windows.Forms.DataGridViewTextBoxColumn on;
        private System.Windows.Forms.DataGridViewTextBoxColumn g;
        private System.Windows.Forms.DataGridViewTextBoxColumn mn;
        private System.Windows.Forms.DataGridViewTextBoxColumn f;
        private System.Windows.Forms.DataGridViewTextBoxColumn d;
        private System.Windows.Forms.DataGridViewTextBoxColumn l;
        private System.Windows.Forms.DataGridViewTextBoxColumn c;
        private System.Windows.Forms.DataGridViewTextBoxColumn reg;
        private System.Windows.Forms.DataGridViewTextBoxColumn Data_id;
    }
}