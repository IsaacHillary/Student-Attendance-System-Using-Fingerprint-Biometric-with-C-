﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class ChangeLoginForm : Form
    {
        public ChangeLoginForm()
        {
            InitializeComponent();
        }

        DBconnection con = new DBconnection();

        private void ChangeLoginForm_Load(object sender, EventArgs e)
        {
            groupBoxNewLogins.Enabled = false;
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            
            try
            {             
                con.dataGet("SELECT * FROM LoginTb WHERE username='" + txtOldUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS and password='" + txtOldPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    groupBoxOldLogins.Enabled = false;
                    groupBoxNewLogins.Enabled = true;
                    txtOldUsername.Clear();
                    txtOldPassword.Clear();
                }
                else
                {
                    MessageBox.Show("Authentication Failed, Try Again!!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            groupBoxOldLogins.Enabled = true;
            groupBoxNewLogins.Enabled = false;
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtNewUsername.Text != "" && txtNewPassword.Text != "")
                {
                    con.dataSend("UPDATE LoginTb SET password ='"+ txtNewPassword.Text +"', username ='"+ txtNewUsername.Text +"' ");
                    txtNewUsername.Clear();
                    txtNewPassword.Clear();
                    MessageBox.Show("Login Changed Successfully");
                }
                else
                {
                    MessageBox.Show("Make Sure to fill all fields!","Info",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
