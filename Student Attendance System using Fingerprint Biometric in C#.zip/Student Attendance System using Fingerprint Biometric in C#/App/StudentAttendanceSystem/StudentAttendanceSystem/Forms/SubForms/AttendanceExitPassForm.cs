﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class AttendanceExitPassForm : Form
    {
        public AttendanceExitPassForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            try
            {
                DBconnection con = new DBconnection();
                con.dataGet("SELECT * FROM LoginTb WHERE password='" + txtPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    AttendanceForm close = (AttendanceForm)Application.OpenForms["AttendanceForm"];
                    close.Close();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Password!!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
