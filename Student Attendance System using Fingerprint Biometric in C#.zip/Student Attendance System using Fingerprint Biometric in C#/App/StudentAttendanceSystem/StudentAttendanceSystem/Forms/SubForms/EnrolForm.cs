﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class EnrolForm : Form
    {
        public static string sn;
        public static string on;
        public static string g;
        public static string mn;
        public static string f;
        public static string d;
        public static string l;
        public static string c;

        public EnrolForm()
        {
            InitializeComponent();
        }

        private bool validation()
        {
            bool result = false;
            if (string.IsNullOrEmpty(txtSurname.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(panel1, "Surname Required");
            }
            else if (string.IsNullOrEmpty(txtOtherNames.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(panel2, "Other Names Required");
            }
            else if (string.IsNullOrEmpty(cbGender.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbGender, "Gender Required");
            }
            else if (string.IsNullOrEmpty(txtMatNo.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(panel3, "Mat. Number Required");
            }
            else if (string.IsNullOrEmpty(cbFaculty.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbFaculty, "Faculty Required");
            }
            else if (string.IsNullOrEmpty(cbDepartment.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbDepartment, "Department Required");
            }
            else if (string.IsNullOrEmpty(cbLevel.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbLevel, "Student Level Required");
            }
            else if (string.IsNullOrEmpty(cbSelectCourse.Text))
            {
                errorProvider.Clear();
                errorProvider.SetError(cbSelectCourse, "Course Required");
            }
            else
            {
                errorProvider.Clear();
                result = true;
            }
            return result;
        }

        public class cbItem
        {
            public string Name;
            public List<cbItem> SubItems = new List<cbItem>();

            public cbItem(string name)
            {
                this.Name = name;
            }

            public override string ToString()
            {
                return Name;
            }
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void EnrolForm_Load(object sender, EventArgs e)
        {
            //create a list for data items (Faculty)
            List<cbItem> cbFacultyItem = new List<cbItem>();

            //assign sub items (Department)
            cbFacultyItem.Add(new cbItem("Humanities and Arts")
            {
                SubItems = { new cbItem("Mass Communication") }
            });

            cbFacultyItem.Add(new cbItem("Law")
            {
                SubItems = { new cbItem("Law") }
            });

            cbFacultyItem.Add(new cbItem("Management and Social Sciences")
            {
                SubItems = { new cbItem("Accounting"), new cbItem("Banking and Finance"),
                    new cbItem("Business Administration"), new cbItem("Economics") }
            });

            cbFacultyItem.Add(new cbItem("Natural and Applied Sciences")
            {
                SubItems = { new cbItem("Biochemistry"), new cbItem("Biology"),
                    new cbItem("Biotechnology"), new cbItem("Computer Science"),
                    new cbItem("Industrial Chemistry"), new cbItem("Industrial Mathematics"),
                    new cbItem("Industrial Physics") }
            });

            //load data items into cbFaculty
            cbFaculty.Items.AddRange(cbFacultyItem.ToArray());

            //Load Course From DB Course Table
            DataRow dr;
            SqlConnection conn = new SqlConnection(@"server=.\SQLEXPRESS; database=StudentAttendanceSystemDB; Integrated Security = true");
            conn.Open();
            SqlCommand cmd = new SqlCommand("select CourseID, CourseCode, CourseTitle from CourseTb", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dr = dt.NewRow();
            dr.ItemArray = new object[] { 0, "" };
            dt.Rows.InsertAt(dr, 0);
            cbSelectCourse.ValueMember = "CourseID";
            cbSelectCourse.DisplayMember = "CourseCode";
            cbSelectCourse.DataSource = dt;
            conn.Close();
        }

        private void cbFaculty_SelectedIndexChanged(object sender, EventArgs e)
        {
            //get the combobox item
            cbItem item = (sender as ComboBox).SelectedItem as cbItem;

            //make sure no shinanigans are going on
            if (item == null)
                return;

            //clear out cbDepartment
            cbDepartment.Items.Clear();

            //add sub items to cbDepartment
            cbDepartment.Items.AddRange(item.SubItems.ToArray());
        }

        private void btnScan_Std_Click(object sender, EventArgs e)
        {
            if (validation())
            {              
                sn = txtSurname.Text;
                on = txtOtherNames.Text;
                g = cbGender.Text;
                mn = txtMatNo.Text;
                f = cbFaculty.Text;
                d = cbDepartment.Text;
                l = cbLevel.Text;
                c = cbSelectCourse.Text;

                new FingerPrintScanner().ShowDialog();
            }
        }
     }
}
