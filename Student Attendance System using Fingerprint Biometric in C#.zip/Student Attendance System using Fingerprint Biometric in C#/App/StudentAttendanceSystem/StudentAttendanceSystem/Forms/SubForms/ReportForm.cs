﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace StudentAttendanceSystem.Forms.SubForms
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }

        DBconnection con = new DBconnection();
        private void ReportForm_Load(object sender, EventArgs e)
        {
            //Load Course From DB Course Table
            DataRow dr;
            SqlConnection conn = new SqlConnection(@"server=.\SQLEXPRESS; database=StudentAttendanceSystemDB; Integrated Security = true");
            conn.Open();
            SqlCommand cmd = new SqlCommand("select CourseID, CourseCode, CourseTitle from CourseTb", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dr = dt.NewRow();
            dr.ItemArray = new object[] { 0, "" };
            dt.Rows.InsertAt(dr, 0);
            cbSelectCourse.ValueMember = "CourseID";
            cbSelectCourse.DisplayMember = "CourseCode";
            cbSelectCourse.DataSource = dt;
            conn.Close();
        }

        private void reload()
        {
            con.dataGet("SELECT Surname, Other_names, Std_matric, Faculty, Department, Std_level, Std_course, Attendance_count FROM StudentTb WHERE Std_course = '" + cbSelectCourse.Text + "'");

            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridVeiw.Rows.Clear();
            foreach (DataRow row in dt.Rows)
            {
                int n = dataGridVeiw.Rows.Add();
                dataGridVeiw.Rows[n].Cells["sn"].Value = n + 1;
                dataGridVeiw.Rows[n].Cells["surn"].Value = row["Surname"].ToString();
                dataGridVeiw.Rows[n].Cells["on"].Value = row["Other_names"].ToString();
                dataGridVeiw.Rows[n].Cells["mn"].Value = row["Std_matric"].ToString();
                dataGridVeiw.Rows[n].Cells["f"].Value = row["Faculty"].ToString();
                dataGridVeiw.Rows[n].Cells["d"].Value = row["Department"].ToString();
                dataGridVeiw.Rows[n].Cells["l"].Value = row["Std_level"].ToString();
                dataGridVeiw.Rows[n].Cells["c"].Value = row["Std_course"].ToString();
                dataGridVeiw.Rows[n].Cells["AC"].Value = row["Attendance_count"].ToString();
            }
        }

        private void reload1()
        {
            con.dataGet("SELECT Surname, Other_names, Std_matric, Faculty, Department, Std_level, Std_course, Attendance_count, Att_percent FROM StudentTb WHERE Std_course = '" + cbSelectCourse.Text + "'");

            DataTable dt = new DataTable();
            con.sda.Fill(dt);
            dataGridVeiw.Rows.Clear();
            foreach (DataRow row in dt.Rows)
            {
                int n = dataGridVeiw.Rows.Add();
                dataGridVeiw.Rows[n].Cells["sn"].Value = n + 1;
                dataGridVeiw.Rows[n].Cells["surn"].Value = row["Surname"].ToString();
                dataGridVeiw.Rows[n].Cells["on"].Value = row["Other_names"].ToString();
                dataGridVeiw.Rows[n].Cells["mn"].Value = row["Std_matric"].ToString();
                dataGridVeiw.Rows[n].Cells["f"].Value = row["Faculty"].ToString();
                dataGridVeiw.Rows[n].Cells["d"].Value = row["Department"].ToString();
                dataGridVeiw.Rows[n].Cells["l"].Value = row["Std_level"].ToString();
                dataGridVeiw.Rows[n].Cells["c"].Value = row["Std_course"].ToString();
                dataGridVeiw.Rows[n].Cells["AC"].Value = row["Attendance_count"].ToString();
                dataGridVeiw.Rows[n].Cells["AP"].Value = row["Att_percent"].ToString();
            }
        }

        private void AttBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbSelectCourse.Text))
            {
                MessageBox.Show("Selected a course", "Course", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                con.dataSend("UPDATE StudentTb SET Attendance_count = 0 WHERE Attendance_count IS NULL");
                con.dataSend("UPDATE StudentTb SET Att_percent = 0 WHERE Att_percent IS NULL");
                reload();
                
                con.dataGet("SELECT CourseTitle, Session, Semester FROM CourseTb WHERE CourseCode = '" + cbSelectCourse.Text + "'");
                DataTable dat = new DataTable();
                con.sda.Fill(dat);
                foreach (DataRow row in dat.Rows)
                {
                    coursetitle.Text = row["CourseTitle"].ToString();
                    session.Text = row["Session"].ToString();
                    semester.Text = row["Semester"].ToString();
                }

                label4.Visible = true;
                numericUpDown.Visible = true;
                numericUpDown.Visible = true;
                PercentBtn.Visible = true;
            }
        }

        private void PercentBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(numericUpDown.Text))
            {
                MessageBox.Show("Input a value", "Course", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            else
            {
                con.dataSend("UPDATE StudentTb SET Att_percent = (Attendance_count * 100) /'" + Convert.ToInt32(numericUpDown.Value) +"'");
                reload1();
            }
        }
    }
}
