﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StudentAttendanceSystem.Forms.SubForms;



namespace StudentAttendanceSystem.Forms
{
    public partial class AdminForm : Form
    {
        
        public AdminForm()
        {
            InitializeComponent();
            this.sidePnl.Height = this.DashboardBtn.Height;
            this.sidePnl.Top = this.DashboardBtn.Top;
        }

        private void DashboardBtn_Click(object sender, EventArgs e)
        {
            DashboardBtn.ForeColor = Color.FromArgb(5, 7, 51);
            CourseRegBtn.ForeColor = Color.FromArgb(230, 230, 255);
            Std_EnrolBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ReportBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ChangeLoginBtn.ForeColor = Color.FromArgb(230, 230, 255);
            sidePnl.Height = DashboardBtn.Height;
            sidePnl.Top = DashboardBtn.Top;

            if (activeForm != null)
                activeForm.Close();
        }

        private void CourseRegBtn_Click(object sender, EventArgs e)
        {
            DashboardBtn.ForeColor = Color.FromArgb(230, 230, 255);
            CourseRegBtn.ForeColor = Color.FromArgb(5, 7, 51);
            Std_EnrolBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ReportBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ChangeLoginBtn.ForeColor = Color.FromArgb(230, 230, 255);
            sidePnl.Height = CourseRegBtn.Height;
            sidePnl.Top = CourseRegBtn.Top;

            openChildForm(new CourseRegForm());
        }

        private void Std_EnrolBtn_Click(object sender, EventArgs e)
        {
            DashboardBtn.ForeColor = Color.FromArgb(230, 230, 255);
            CourseRegBtn.ForeColor = Color.FromArgb(230, 230, 255);
            Std_EnrolBtn.ForeColor = Color.FromArgb(5, 7, 51);
            ReportBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ChangeLoginBtn.ForeColor = Color.FromArgb(230, 230, 255);
            sidePnl.Height = Std_EnrolBtn.Height;
            sidePnl.Top = Std_EnrolBtn.Top;

            openChildForm(new StudentForm());
        }

        private void ReportBtn_Click(object sender, EventArgs e)
        {
            DashboardBtn.ForeColor = Color.FromArgb(230, 230, 255);
            CourseRegBtn.ForeColor = Color.FromArgb(230, 230, 255);
            Std_EnrolBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ReportBtn.ForeColor = Color.FromArgb(5, 7, 51);
            ChangeLoginBtn.ForeColor = Color.FromArgb(230, 230, 255);
            sidePnl.Height = ReportBtn.Height;
            sidePnl.Top = ReportBtn.Top;

            openChildForm(new ReportForm());
        }

        private void ChangeLoginBtn_Click(object sender, EventArgs e)
        {
            DashboardBtn.ForeColor = Color.FromArgb(230, 230, 255);
            CourseRegBtn.ForeColor = Color.FromArgb(230, 230, 255);
            Std_EnrolBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ReportBtn.ForeColor = Color.FromArgb(230, 230, 255);
            ChangeLoginBtn.ForeColor = Color.FromArgb(5, 7, 51);
            sidePnl.Height = ChangeLoginBtn.Height;
            sidePnl.Top = ChangeLoginBtn.Top;

            openChildForm(new ChangeLoginForm());
        }

        private void LogOutBtn_Click(object sender, EventArgs e)
        {
            switch (MessageBox.Show("DO YOU WANT TO LOGOUT?", "LOGOUT", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
            {
                case DialogResult.Yes:
                    this.Hide();
                    new LoginForm().ShowDialog();
                    this.Close();
                    break;
                case DialogResult.No:
                    this.Activate();
                    break;
            }
        }

        private void MinimizeBtn_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void basePnl_Paint(object sender, PaintEventArgs e)
        {
            timer1.Start();
            time.Text = DateTime.Now.ToLongTimeString();
            date.Text = DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private Form activeForm = null;
        private void openChildForm(Form ChildForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = ChildForm;
            ChildForm.TopLevel = false;
            ChildForm.FormBorderStyle = FormBorderStyle.None;
            ChildForm.Dock = DockStyle.Fill;
            ChildFormPnl.Controls.Add(ChildForm);
            ChildFormPnl.Tag = ChildForm;
            ChildForm.BringToFront();
            ChildForm.Show();
        }

        private void AttendanceBtn_Click(object sender, EventArgs e)
        {
            new ActivateAttendanceForm().ShowDialog();
        }
    }
}
