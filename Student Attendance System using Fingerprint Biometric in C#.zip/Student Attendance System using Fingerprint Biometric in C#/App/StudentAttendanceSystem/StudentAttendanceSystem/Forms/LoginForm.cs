﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StudentAttendanceSystem.Forms;

namespace StudentAttendanceSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            this.timer1.Start();
            this.ActiveControl = txtLoginUser;
            this.time.Text = DateTime.Now.ToLongTimeString();
            this.date.Text = DateTime.Now.ToLongDateString();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void hidePassword_Click(object sender, EventArgs e)
        {
            this.txtLoginPassword.UseSystemPasswordChar = false;
            this.showPassword.Visible = true;
            this.hidePassword.Visible = false;
        }

        private void showPassword_Click(object sender, EventArgs e)
        {
            this.txtLoginPassword.UseSystemPasswordChar = true;
            this.showPassword.Visible = false;
            this.hidePassword.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.time.Text = DateTime.Now.ToLongTimeString();
            this.timer1.Start();
        }

        private void txtLoginUser_Click(object sender, EventArgs e)
        {
            this.txtLoginUser.BackColor = Color.FromArgb(230, 230, 255);
            this.pnlLoginUser.BackColor = Color.FromArgb(230, 230, 255);
            this.pnlLoginPassword.BackColor = Color.FromArgb(192, 192, 255);
            this.txtLoginPassword.BackColor = Color.FromArgb(192, 192, 255);
        }

        private void txtLoginPassword_Click(object sender, EventArgs e)
        {
            this.txtLoginUser.BackColor = Color.FromArgb(192, 192, 255);
            this.pnlLoginUser.BackColor = Color.FromArgb(192, 192, 255);
            this.pnlLoginPassword.BackColor = Color.FromArgb(230, 230, 255);
            this.txtLoginPassword.BackColor = Color.FromArgb(230, 230, 255);
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                DBconnection con = new DBconnection();
                con.dataGet("SELECT * FROM LoginTb WHERE (username='"+ txtLoginUser.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS and password='"+ txtLoginPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS)");
                DataTable dt = new DataTable();
                con.sda.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    this.Hide();
                    new AdminForm().ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Invalid Login!!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
